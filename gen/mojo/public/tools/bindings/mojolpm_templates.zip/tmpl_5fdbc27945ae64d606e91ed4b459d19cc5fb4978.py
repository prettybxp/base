from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'mojolpm_traits_specialization_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_util = l_0_define_struct = l_0_define_union = missing
    try:
        t_1 = environment.filters['camel_to_under']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'camel_to_under' found.")
    try:
        t_2 = environment.filters['cpp_wrapper_type']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_type' found.")
    try:
        t_3 = environment.filters['default_constructor_args']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'default_constructor_args' found.")
    try:
        t_4 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_5 = environment.filters['is_nullable_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_kind' found.")
    try:
        t_6 = environment.filters['is_typemapped_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_typemapped_kind' found.")
    try:
        t_7 = environment.filters['nullable_is_same_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'nullable_is_same_kind' found.")
    try:
        t_8 = environment.filters['to_unnullable_kind']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'to_unnullable_kind' found.")
    try:
        t_9 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    pass
    l_0_util = context.vars['util'] = environment.get_template('mojolpm_macros.tmpl', 'mojolpm_traits_specialization_macros.tmpl')._get_default_module(context)
    context.exported_vars.discard('util')
    def macro(l_1_struct):
        t_10 = []
        l_1_mojom_type = l_1_proto_type = l_1_struct_type = l_1_dataview_type = missing
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        pass
        l_1_mojom_type = t_2(l_1_struct, add_same_module_namespaces=True)
        l_1_proto_type = str_join(('::mojolpm', t_4(l_1_struct, flatten_nested_kind=True), ))
        l_1_struct_type = str_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoStruct', ))
        l_1_dataview_type = str_join((t_4(l_1_struct, flatten_nested_kind=True), 'DataView', ))
        t_10.extend((
            '\ntemplate <>\nstruct StructTraits<',
            str((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
            ', ',
            str((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
            '> {',
        ))
        for l_2_field in environment.getattr(l_1_struct, 'fields'):
            l_2_field_mojom_type = resolve('field_mojom_type')
            l_2_unnullable_kind = resolve('unnullable_kind')
            l_2_field_maybe_mojom_type = resolve('field_maybe_mojom_type')
            l_2_name = l_2_kind = missing
            _loop_vars = {}
            pass
            l_2_name = t_1(environment.getattr(l_2_field, 'name'))
            _loop_vars['name'] = l_2_name
            l_2_kind = environment.getattr(l_2_field, 'kind')
            _loop_vars['kind'] = l_2_kind
            if (t_5(environment.getattr(l_2_field, 'kind')) and (not t_7(environment.getattr(l_2_field, 'kind')))):
                pass
                l_2_field_mojom_type = t_2((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)
                _loop_vars['field_mojom_type'] = l_2_field_mojom_type
                l_2_unnullable_kind = t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind))
                _loop_vars['unnullable_kind'] = l_2_unnullable_kind
                l_2_field_maybe_mojom_type = t_2((undefined(name='unnullable_kind') if l_2_unnullable_kind is missing else l_2_unnullable_kind), add_same_module_namespaces=True)
                _loop_vars['field_maybe_mojom_type'] = l_2_field_maybe_mojom_type
                t_10.extend((
                    '\n  static ',
                    str((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                    ' ',
                    str(environment.getattr(l_2_field, 'name')),
                    '(\n      const ',
                    str((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
                    '& input) {\n    ',
                    str((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                    ' maybe_local_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    '{',
                    str(t_3((undefined(name='kind') if l_2_kind is missing else l_2_kind))),
                    '};\n    ',
                    str((undefined(name='field_maybe_mojom_type') if l_2_field_maybe_mojom_type is missing else l_2_field_maybe_mojom_type)),
                    ' local_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    '{',
                    str(t_3((undefined(name='unnullable_kind') if l_2_unnullable_kind is missing else l_2_unnullable_kind))),
                    '};\n    if (input.has_m_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    '() && mojolpm::FromProto(\n      input.m_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    '(),\n      local_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ')) {\n      maybe_local_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ' = std::move(local_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ');\n    }\n    return maybe_local_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ';\n  }\n',
                ))
            else:
                pass
                l_2_field_mojom_type = t_2((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)
                _loop_vars['field_mojom_type'] = l_2_field_mojom_type
                t_10.extend((
                    '\n  static ',
                    str((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                    ' ',
                    str(environment.getattr(l_2_field, 'name')),
                    '(\n      const ',
                    str((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
                    '& input) {\n    ',
                    str((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                    ' local_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    '{',
                    str(t_3((undefined(name='kind') if l_2_kind is missing else l_2_kind))),
                    '};\n    (void) mojolpm::FromProto(\n      input.m_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    '(),\n      local_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ');\n    return local_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ';\n  }\n',
                ))
        l_2_field = l_2_name = l_2_kind = l_2_field_mojom_type = l_2_unnullable_kind = l_2_field_maybe_mojom_type = missing
        t_10.append(
            '};\n',
        )
        return concat(t_10)
    context.exported_vars.add('define_struct')
    context.vars['define_struct'] = l_0_define_struct = Macro(environment, macro, 'define_struct', ('struct',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_union):
        t_11 = []
        l_1_dataview_type = resolve('dataview_type')
        l_1_mojom_type = l_1_proto_type = l_1_union_type = missing
        if l_1_union is missing:
            l_1_union = undefined("parameter 'union' was not provided", name='union')
        pass
        l_1_mojom_type = t_2(l_1_union, add_same_module_namespaces=True)
        l_1_proto_type = str_join(('::mojolpm', t_4(l_1_union, flatten_nested_kind=True), ))
        l_1_union_type = str_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoUnion', ))
        if t_6(l_1_union):
            pass
            l_1_dataview_type = str_join((t_4(l_1_union, flatten_nested_kind=True), 'DataView', ))
            t_11.extend((
                '\ntemplate<>\nstruct UnionTraits<',
                str((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
                ', ',
                str((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
                '> {\n  static ',
                str((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
                '::Tag GetTag(\n      const ',
                str((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
                '& input) {\n    switch (input.union_member_case()) {',
            ))
            for l_2_field in environment.getattr(l_1_union, 'fields'):
                l_2_name = l_2_kind = l_2_field_mojom_type = missing
                _loop_vars = {}
                pass
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                _loop_vars['name'] = l_2_name
                l_2_kind = environment.getattr(l_2_field, 'kind')
                _loop_vars['kind'] = l_2_kind
                l_2_field_mojom_type = t_2((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)
                _loop_vars['field_mojom_type'] = l_2_field_mojom_type
                t_11.extend((
                    '\n      case ',
                    str((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
                    '::k',
                    str(t_9(str_join(('m_', (undefined(name='name') if l_2_name is missing else l_2_name), )))),
                    ':\n        return ',
                    str((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
                    '::Tag::k',
                    str(t_9((undefined(name='name') if l_2_name is missing else l_2_name))),
                    ';',
                ))
            l_2_field = l_2_name = l_2_kind = l_2_field_mojom_type = missing
            t_11.extend((
                '\n      default:\n        return static_cast<',
                str((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
                '::Tag>(0);\n    }\n  }\n',
            ))
            for l_2_field in environment.getattr(l_1_union, 'fields'):
                l_2_field_mojom_type = resolve('field_mojom_type')
                l_2_unnullable_kind = resolve('unnullable_kind')
                l_2_field_maybe_mojom_type = resolve('field_maybe_mojom_type')
                l_2_name = l_2_kind = missing
                _loop_vars = {}
                pass
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                _loop_vars['name'] = l_2_name
                l_2_kind = environment.getattr(l_2_field, 'kind')
                _loop_vars['kind'] = l_2_kind
                if (t_5(environment.getattr(l_2_field, 'kind')) and (not t_7(environment.getattr(l_2_field, 'kind')))):
                    pass
                    l_2_field_mojom_type = t_2((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)
                    _loop_vars['field_mojom_type'] = l_2_field_mojom_type
                    l_2_unnullable_kind = t_8((undefined(name='kind') if l_2_kind is missing else l_2_kind))
                    _loop_vars['unnullable_kind'] = l_2_unnullable_kind
                    l_2_field_maybe_mojom_type = t_2((undefined(name='unnullable_kind') if l_2_unnullable_kind is missing else l_2_unnullable_kind), add_same_module_namespaces=True)
                    _loop_vars['field_maybe_mojom_type'] = l_2_field_maybe_mojom_type
                    t_11.extend((
                        '\n  static ',
                        str((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                        ' ',
                        str(environment.getattr(l_2_field, 'name')),
                        '(\n      const ',
                        str((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
                        '& input) {\n    ',
                        str((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                        ' maybe_local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '{',
                        str(t_3((undefined(name='kind') if l_2_kind is missing else l_2_kind))),
                        '};\n    ',
                        str((undefined(name='field_maybe_mojom_type') if l_2_field_maybe_mojom_type is missing else l_2_field_maybe_mojom_type)),
                        ' local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '{',
                        str(t_3((undefined(name='unnullable_kind') if l_2_unnullable_kind is missing else l_2_unnullable_kind))),
                        '};\n    if (mojolpm::FromProto(\n      input.m_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(),\n      local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ')) {\n      maybe_local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ' = std::move(local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n    }\n    return maybe_local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n  }\n',
                    ))
                else:
                    pass
                    l_2_field_mojom_type = t_2((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)
                    _loop_vars['field_mojom_type'] = l_2_field_mojom_type
                    t_11.extend((
                        '\n  static ',
                        str((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                        ' ',
                        str(environment.getattr(l_2_field, 'name')),
                        '(\n      const ',
                        str((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
                        '& input) {\n    ',
                        str((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                        ' local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '{',
                        str(t_3((undefined(name='kind') if l_2_kind is missing else l_2_kind))),
                        '};\n    (void) mojolpm::FromProto(\n      input.m_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(),\n      local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n    return local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ';\n  }\n',
                    ))
            l_2_field = l_2_name = l_2_kind = l_2_field_mojom_type = l_2_unnullable_kind = l_2_field_maybe_mojom_type = missing
            t_11.append(
                '};\n',
            )
        t_11.append(
            '\n',
        )
        return concat(t_11)
    context.exported_vars.add('define_union')
    context.vars['define_union'] = l_0_define_union = Macro(environment, macro, 'define_union', ('union',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=66&3=68&4=74&5=75&6=76&7=77&9=80&10=85&11=92&12=94&13=96&14=98&15=100&16=102&17=106&18=110&19=112&20=118&21=124&22=126&23=128&24=130&26=134&29=139&30=143&31=147&32=149&34=155&35=157&36=159&43=169&44=176&45=177&46=178&47=179&48=181&50=184&51=188&52=190&54=193&55=197&56=199&57=201&58=205&59=209&62=217&65=220&66=227&67=229&68=231&69=233&70=235&71=237&72=241&73=245&74=247&75=253&77=259&78=261&79=263&81=267&84=272&85=276&86=280&87=282&89=288&90=290&91=292'