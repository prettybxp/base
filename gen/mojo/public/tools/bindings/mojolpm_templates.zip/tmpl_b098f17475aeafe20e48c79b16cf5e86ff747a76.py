from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'mojolpm_from_proto_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_util = l_0_declare_array = l_0_declare_map = l_0_declare = l_0_define_array = l_0_define_map = l_0_define = l_0_define_enum = l_0_define_struct = l_0_define_union = missing
    try:
        t_1 = environment.filters['camel_to_under']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'camel_to_under' found.")
    try:
        t_2 = environment.filters['cpp_wrapper_call_type']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_call_type' found.")
    try:
        t_3 = environment.filters['cpp_wrapper_type']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_type' found.")
    try:
        t_4 = environment.filters['default_constructor_args']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'default_constructor_args' found.")
    try:
        t_5 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_6 = environment.filters['is_array_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_array_kind' found.")
    try:
        t_7 = environment.filters['is_map_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_map_kind' found.")
    try:
        t_8 = environment.filters['is_native_only_kind']
    except KeyError:
        @internalcode
        def t_8(*unused):
            raise TemplateRuntimeError("No filter named 'is_native_only_kind' found.")
    try:
        t_9 = environment.filters['is_nullable_kind']
    except KeyError:
        @internalcode
        def t_9(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_kind' found.")
    try:
        t_10 = environment.filters['is_typemapped_kind']
    except KeyError:
        @internalcode
        def t_10(*unused):
            raise TemplateRuntimeError("No filter named 'is_typemapped_kind' found.")
    try:
        t_11 = environment.filters['to_unnullable_kind']
    except KeyError:
        @internalcode
        def t_11(*unused):
            raise TemplateRuntimeError("No filter named 'to_unnullable_kind' found.")
    try:
        t_12 = environment.filters['under_to_camel']
    except KeyError:
        @internalcode
        def t_12(*unused):
            raise TemplateRuntimeError("No filter named 'under_to_camel' found.")
    pass
    l_0_util = context.vars['util'] = environment.get_template('mojolpm_macros.tmpl', 'mojolpm_from_proto_macros.tmpl')._get_default_module(context)
    context.exported_vars.discard('util')
    def macro(l_1_type, l_1_kind):
        t_13 = []
        l_1_mojom_maybe_type = resolve('mojom_maybe_type')
        l_1_mojom_type = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        l_1_mojom_type = t_3(environment.getattr(l_1_kind, 'kind'), add_same_module_namespaces=True)
        if t_9(environment.getattr(l_1_kind, 'kind')):
            pass
            l_1_mojom_maybe_type = t_3(t_11(environment.getattr(l_1_kind, 'kind')), add_same_module_namespaces=True)
        else:
            pass
            l_1_mojom_maybe_type = (undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)
        t_13.extend((
            '\nbool FromProto(\n  const ',
            str(l_1_type),
            '& input,\n  std::vector<',
            str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            '>& output);\n',
        ))
        if t_6(environment.getattr(l_1_kind, 'kind')):
            pass
            t_13.extend((
                '\n',
                str(context.call((undefined(name='declare_array') if l_0_declare_array is missing else l_0_declare_array), str_join((l_1_type, 'Entry', )), environment.getattr(l_1_kind, 'kind'))),
            ))
        elif t_7(environment.getattr(l_1_kind, 'kind')):
            pass
            t_13.extend((
                '\n',
                str(context.call((undefined(name='declare_map') if l_0_declare_map is missing else l_0_declare_map), str_join((l_1_type, 'Entry', )), environment.getattr(l_1_kind, 'kind'))),
            ))
        elif t_9(environment.getattr(l_1_kind, 'kind')):
            pass
            t_13.extend((
                '\nbool FromProto(\n  const ',
                str(l_1_type),
                'Entry& input,\n  ',
                str((undefined(name='mojom_maybe_type') if l_1_mojom_maybe_type is missing else l_1_mojom_maybe_type)),
                '& output);\n',
            ))
        else:
            pass
            t_13.extend((
                '\nbool FromProto(\n  const ',
                str(l_1_type),
                'Entry& input,\n  ',
                str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '& output);\n',
            ))
        return concat(t_13)
    context.exported_vars.add('declare_array')
    context.vars['declare_array'] = l_0_declare_array = Macro(environment, macro, 'declare_array', ('type', 'kind'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_type, l_1_kind):
        t_14 = []
        l_1_mojom_maybe_value_type = resolve('mojom_maybe_value_type')
        l_1_mojom_key_type = l_1_mojom_value_type = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        l_1_mojom_key_type = t_3(environment.getattr(l_1_kind, 'key_kind'), add_same_module_namespaces=True)
        l_1_mojom_value_type = t_3(environment.getattr(l_1_kind, 'value_kind'), add_same_module_namespaces=True)
        if t_9(environment.getattr(l_1_kind, 'value_kind')):
            pass
            l_1_mojom_maybe_value_type = t_3(t_11(environment.getattr(l_1_kind, 'value_kind')), add_same_module_namespaces=True)
        else:
            pass
            l_1_mojom_maybe_value_type = (undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)
        t_14.extend((
            '\nbool FromProto(\n  const ',
            str(l_1_type),
            '& input,\n  base::flat_map<',
            str((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
            ',\n  ',
            str((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
            '>& output);\n',
        ))
        if t_6(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_14.append(
                str(context.call((undefined(name='declare_array') if l_0_declare_array is missing else l_0_declare_array), str_join((l_1_type, 'Key', )), environment.getattr(l_1_kind, 'key_kind'))),
            )
        elif t_7(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_14.append(
                str(context.call((undefined(name='declare_map') if l_0_declare_map is missing else l_0_declare_map), str_join((l_1_type, 'Key', )), environment.getattr(l_1_kind, 'key_kind'))),
            )
        else:
            pass
            t_14.extend((
                '\nbool FromProto(\n  const ',
                str(l_1_type),
                'Key& input,\n  ',
                str((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                '& output);\n',
            ))
        if t_6(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_14.append(
                str(context.call((undefined(name='declare_array') if l_0_declare_array is missing else l_0_declare_array), str_join((l_1_type, 'Value', )), environment.getattr(l_1_kind, 'value_kind'))),
            )
        elif t_7(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_14.append(
                str(context.call((undefined(name='declare_map') if l_0_declare_map is missing else l_0_declare_map), str_join((l_1_type, 'Value', )), environment.getattr(l_1_kind, 'value_kind'))),
            )
        elif t_9(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_14.extend((
                '\nbool FromProto(\n  const ',
                str(l_1_type),
                'Value& input,\n  ',
                str((undefined(name='mojom_maybe_value_type') if l_1_mojom_maybe_value_type is missing else l_1_mojom_maybe_value_type)),
                '& output);\n',
            ))
        else:
            pass
            t_14.extend((
                '\nbool FromProto(\n  const ',
                str(l_1_type),
                'Value& input,\n  ',
                str((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                '& output);\n',
            ))
        return concat(t_14)
    context.exported_vars.add('declare_map')
    context.vars['declare_map'] = l_0_declare_map = Macro(environment, macro, 'declare_map', ('type', 'kind'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_parent_name, l_1_kind, l_1_name):
        t_15 = []
        l_1_array_type = resolve('array_type')
        l_1_map_type = resolve('map_type')
        if l_1_parent_name is missing:
            l_1_parent_name = undefined("parameter 'parent_name' was not provided", name='parent_name')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_6(l_1_kind):
            pass
            l_1_array_type = str_join((l_1_parent_name, '::', t_12(l_1_name), '_Array', ))
            t_15.append(
                str(context.call((undefined(name='declare_array') if l_0_declare_array is missing else l_0_declare_array), (undefined(name='array_type') if l_1_array_type is missing else l_1_array_type), l_1_kind)),
            )
        elif t_7(l_1_kind):
            pass
            l_1_map_type = str_join((l_1_parent_name, '::', t_12(l_1_name), '_Map', ))
            t_15.append(
                str(context.call((undefined(name='declare_map') if l_0_declare_map is missing else l_0_declare_map), (undefined(name='map_type') if l_1_map_type is missing else l_1_map_type), l_1_kind)),
            )
        return concat(t_15)
    context.exported_vars.add('declare')
    context.vars['declare'] = l_0_declare = Macro(environment, macro, 'declare', ('parent_name', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_type, l_1_kind):
        t_16 = []
        l_1_unnullable_kind = resolve('unnullable_kind')
        l_1_mojom_maybe_type = resolve('mojom_maybe_type')
        l_1_mojom_type = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        l_1_mojom_type = t_3(environment.getattr(l_1_kind, 'kind'), add_same_module_namespaces=True)
        t_16.extend((
            '\nbool FromProto(\n    const ',
            str(l_1_type),
            '& input,\n    std::vector<',
            str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            '>& output) {\n  bool result = true;\n\n  output.reserve(input.values_size());\n  for (const auto& entry : input.values()) {\n    ',
            str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            ' value{',
            str(t_4(environment.getattr(l_1_kind, 'kind'))),
            '};',
        ))
        if t_9(environment.getattr(l_1_kind, 'kind')):
            pass
            l_1_unnullable_kind = t_11(environment.getattr(l_1_kind, 'kind'))
            l_1_mojom_maybe_type = t_3((undefined(name='unnullable_kind') if l_1_unnullable_kind is missing else l_1_unnullable_kind), add_same_module_namespaces=True)
            t_16.extend((
                '\n    ',
                str((undefined(name='mojom_maybe_type') if l_1_mojom_maybe_type is missing else l_1_mojom_maybe_type)),
                ' maybe_value{',
                str(t_4((undefined(name='unnullable_kind') if l_1_unnullable_kind is missing else l_1_unnullable_kind))),
                '};\n    if (entry.has_value() && FromProto(entry.value(), maybe_value)) {\n      value = std::move(maybe_value);\n    }',
            ))
        elif (t_7(environment.getattr(l_1_kind, 'kind')) or t_6(environment.getattr(l_1_kind, 'kind'))):
            pass
            t_16.append(
                '\n    result = FromProto(entry, value);\n    if (!result) {\n      break;\n    }',
            )
        else:
            pass
            t_16.append(
                '\n    result = FromProto(entry.value(), value);\n    if (!result) {\n      break;\n    }',
            )
        t_16.append(
            '\n    output.emplace_back(std::move(value));\n}\n\n  return result;\n}\n',
        )
        if t_6(environment.getattr(l_1_kind, 'kind')):
            pass
            t_16.append(
                str(context.call((undefined(name='define_array') if l_0_define_array is missing else l_0_define_array), str_join((l_1_type, 'Entry', )), environment.getattr(l_1_kind, 'kind'))),
            )
        elif t_7(environment.getattr(l_1_kind, 'kind')):
            pass
            t_16.append(
                str(context.call((undefined(name='define_map') if l_0_define_map is missing else l_0_define_map), str_join((l_1_type, 'Entry', )), environment.getattr(l_1_kind, 'kind'))),
            )
        elif t_9(environment.getattr(l_1_kind, 'kind')):
            pass
            t_16.extend((
                '\nbool FromProto(\n    const ',
                str(l_1_type),
                'Entry& input,\n    ',
                str((undefined(name='mojom_maybe_type') if l_1_mojom_maybe_type is missing else l_1_mojom_maybe_type)),
                '& output) {\n  return FromProto(input.value(), output);\n}\n',
            ))
        else:
            pass
            t_16.extend((
                '\nbool FromProto(\n    const ',
                str(l_1_type),
                'Entry& input,\n    ',
                str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '& output) {\n  return FromProto(input.value(), output);\n}\n',
            ))
        return concat(t_16)
    context.exported_vars.add('define_array')
    context.vars['define_array'] = l_0_define_array = Macro(environment, macro, 'define_array', ('type', 'kind'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_type, l_1_kind):
        t_17 = []
        l_1_unnullable_value_kind = resolve('unnullable_value_kind')
        l_1_mojom_maybe_value_type = resolve('mojom_maybe_value_type')
        l_1_mojom_key_type = l_1_mojom_value_type = missing
        if l_1_type is missing:
            l_1_type = undefined("parameter 'type' was not provided", name='type')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        pass
        l_1_mojom_key_type = t_3(environment.getattr(l_1_kind, 'key_kind'), add_same_module_namespaces=True)
        l_1_mojom_value_type = t_3(environment.getattr(l_1_kind, 'value_kind'), add_same_module_namespaces=True)
        t_17.extend((
            '\nbool FromProto(\n    const ',
            str(l_1_type),
            '& input,\n    base::flat_map<',
            str((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
            ',\n                   ',
            str((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
            '>& output) {\n  bool result = true;\n  for (const auto& entry : input.values()) {',
        ))
        if t_9(environment.getattr(l_1_kind, 'value_kind')):
            pass
            l_1_unnullable_value_kind = t_11(environment.getattr(l_1_kind, 'value_kind'))
            l_1_mojom_maybe_value_type = t_3((undefined(name='unnullable_value_kind') if l_1_unnullable_value_kind is missing else l_1_unnullable_value_kind), add_same_module_namespaces=True)
            t_17.extend((
                '\n    ',
                str((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                ' key{',
                str(t_4(environment.getattr(l_1_kind, 'key_kind'))),
                '};\n    ',
                str((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                ' value{',
                str(t_4(environment.getattr(l_1_kind, 'value_kind'))),
                '};\n    ',
                str((undefined(name='mojom_maybe_value_type') if l_1_mojom_maybe_value_type is missing else l_1_mojom_maybe_value_type)),
                ' maybe_value{',
                str(t_4((undefined(name='unnullable_value_kind') if l_1_unnullable_value_kind is missing else l_1_unnullable_value_kind))),
                '};\n\n    if (FromProto(entry.key(), key)) {\n      if (FromProto(entry.value(), maybe_value)) {\n        value = std::move(maybe_value);\n      }\n      output.emplace(std::move(key), std::move(value));\n    } else {\n      result = false;\n      break;\n    }',
            ))
        else:
            pass
            t_17.extend((
                '\n    ',
                str((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                ' key{',
                str(t_4(environment.getattr(l_1_kind, 'key_kind'))),
                '};\n    ',
                str((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                ' value{',
                str(t_4(environment.getattr(l_1_kind, 'value_kind'))),
                '};\n\n    if (FromProto(entry.key(), key)\n        && FromProto(entry.value(), value)) {\n      output.emplace(std::move(key), std::move(value));\n    } else {\n      result = false;\n      break;\n    }',
            ))
        t_17.append(
            '\n  }\n\n  return result;\n}\n',
        )
        if t_6(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_17.extend((
                '\n',
                str(context.call((undefined(name='define_array') if l_0_define_array is missing else l_0_define_array), str_join((l_1_type, 'Key', )), environment.getattr(l_1_kind, 'key_kind'))),
            ))
        elif t_7(environment.getattr(l_1_kind, 'key_kind')):
            pass
            t_17.extend((
                '\n',
                str(context.call((undefined(name='define_map') if l_0_define_map is missing else l_0_define_map), str_join((l_1_type, 'Key', )), environment.getattr(l_1_kind, 'key_kind'))),
            ))
        else:
            pass
            t_17.extend((
                '\nbool FromProto(\n    const ',
                str(l_1_type),
                'Key& input,\n    ',
                str((undefined(name='mojom_key_type') if l_1_mojom_key_type is missing else l_1_mojom_key_type)),
                '& output) {\n  return FromProto(input.value(), output);\n}\n',
            ))
        if t_6(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_17.append(
                str(context.call((undefined(name='define_array') if l_0_define_array is missing else l_0_define_array), str_join((l_1_type, 'Value', )), environment.getattr(l_1_kind, 'value_kind'))),
            )
        elif t_7(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_17.append(
                str(context.call((undefined(name='define_map') if l_0_define_map is missing else l_0_define_map), str_join((l_1_type, 'Value', )), environment.getattr(l_1_kind, 'value_kind'))),
            )
        elif t_9(environment.getattr(l_1_kind, 'value_kind')):
            pass
            t_17.extend((
                '\nbool FromProto(\n    const ',
                str(l_1_type),
                'Value& input,\n    ',
                str((undefined(name='mojom_maybe_value_type') if l_1_mojom_maybe_value_type is missing else l_1_mojom_maybe_value_type)),
                '& output) {\n  return FromProto(input.value(), output);\n}\n',
            ))
        else:
            pass
            t_17.extend((
                '\nbool FromProto(\n    const ',
                str(l_1_type),
                'Value& input,\n    ',
                str((undefined(name='mojom_value_type') if l_1_mojom_value_type is missing else l_1_mojom_value_type)),
                '& output) {\n  return FromProto(input.value(), output);\n}\n',
            ))
        return concat(t_17)
    context.exported_vars.add('define_map')
    context.vars['define_map'] = l_0_define_map = Macro(environment, macro, 'define_map', ('type', 'kind'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_parent_name, l_1_kind, l_1_name):
        t_18 = []
        l_1_array_type = resolve('array_type')
        l_1_map_type = resolve('map_type')
        if l_1_parent_name is missing:
            l_1_parent_name = undefined("parameter 'parent_name' was not provided", name='parent_name')
        if l_1_kind is missing:
            l_1_kind = undefined("parameter 'kind' was not provided", name='kind')
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if t_6(l_1_kind):
            pass
            l_1_array_type = str_join((l_1_parent_name, '::', t_12(l_1_name), '_Array', ))
            t_18.append(
                str(context.call((undefined(name='define_array') if l_0_define_array is missing else l_0_define_array), (undefined(name='array_type') if l_1_array_type is missing else l_1_array_type), l_1_kind)),
            )
        elif t_7(l_1_kind):
            pass
            l_1_map_type = str_join((l_1_parent_name, '::', t_12(l_1_name), '_Map', ))
            t_18.append(
                str(context.call((undefined(name='define_map') if l_0_define_map is missing else l_0_define_map), (undefined(name='map_type') if l_1_map_type is missing else l_1_map_type), l_1_kind)),
            )
        return concat(t_18)
    context.exported_vars.add('define')
    context.vars['define'] = l_0_define = Macro(environment, macro, 'define', ('parent_name', 'kind', 'name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_enum):
        t_19 = []
        l_1_mojom_type = l_1_proto_type = l_1_enum_type = missing
        if l_1_enum is missing:
            l_1_enum = undefined("parameter 'enum' was not provided", name='enum')
        pass
        l_1_mojom_type = t_2(l_1_enum, add_same_module_namespaces=True)
        l_1_proto_type = str_join(('::mojolpm', t_5(l_1_enum, flatten_nested_kind=True), ))
        l_1_enum_type = t_5(l_1_enum, flatten_nested_kind=True)
        t_19.extend((
            '\nbool FromProto(\n    const ',
            str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
            '& input,\n    ',
            str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            '& output) {',
        ))
        if (t_8(l_1_enum) or (not t_10(l_1_enum))):
            pass
            t_19.extend((
                "\n  // This ignores IPC_PARAM_TRAITS for native IPC enums, but internal to the\n  // fuzzer we don't want the overhead of the serialization layer if we don't\n  // need it. This doesn't change the actual checks on the receiving end.\n  output = static_cast<",
                str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>(input);\n  return true;',
            ))
        else:
            pass
            t_19.extend((
                '\n  return ::mojo::EnumTraits<',
                str((undefined(name='enum_type') if l_1_enum_type is missing else l_1_enum_type)),
                ', ',
                str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>::FromMojom(\n    static_cast<',
                str((undefined(name='enum_type') if l_1_enum_type is missing else l_1_enum_type)),
                '>(input), &output);',
            ))
        t_19.append(
            '\n}',
        )
        return concat(t_19)
    context.exported_vars.add('define_enum')
    context.vars['define_enum'] = l_0_define_enum = Macro(environment, macro, 'define_enum', ('enum',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_struct):
        t_20 = []
        l_1_dataview_type = resolve('dataview_type')
        l_1_data_type = resolve('data_type')
        l_1_mojom_type = l_1_proto_type = l_1_struct_type = missing
        if l_1_struct is missing:
            l_1_struct = undefined("parameter 'struct' was not provided", name='struct')
        pass
        l_1_mojom_type = t_2(l_1_struct, add_same_module_namespaces=True)
        l_1_proto_type = str_join(('::mojolpm', t_5(l_1_struct, flatten_nested_kind=True), ))
        l_1_struct_type = str_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoStruct', ))
        t_20.extend((
            '\nbool FromProto(\n    const ',
            str((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
            '& input,\n    ',
            str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            '& output) {',
        ))
        if t_8(l_1_struct):
            pass
            t_20.append(
                '\n  memset((void*)&output, 0, sizeof(output));\n  if (input.native_bytes().size() < sizeof(output)) {\n    memcpy((void*)&output, input.native_bytes().data(), input.native_bytes().size());\n  } else {\n    memcpy((void*)&output, input.native_bytes().data(), sizeof(output));\n  }\n  return true;',
            )
        elif t_10(l_1_struct):
            pass
            l_1_dataview_type = str_join((t_5(l_1_struct, flatten_nested_kind=True), 'DataView', ))
            l_1_data_type = t_5(l_1_struct, flatten_nested_kind=True, internal=True)
            t_20.extend((
                '\n  ::mojo::Message mojolpm_message(0, 0, 0, 0, nullptr);\n  ::mojo::internal::MessageFragment<',
                str((undefined(name='data_type') if l_1_data_type is missing else l_1_data_type)),
                '> mojolpm_fragment(\n      mojolpm_message);\n  bool result = false;\n\n  ::mojo::internal::Serializer<',
                str((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
                ', const ',
                str((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
                '>::Serialize(\n    input, mojolpm_fragment);\n  result = ::mojo::internal::Serializer<',
                str((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
                ', ',
                str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>::Deserialize(\n    mojolpm_fragment.data(), &output, &mojolpm_message);\n\n  return result;',
            ))
        elif environment.getattr(l_1_struct, 'fields'):
            pass
            t_20.append(
                '\n  bool mojolpm_result = true;',
            )
            for l_2_field in environment.getattr(l_1_struct, 'fields'):
                l_2_unnullable_kind = resolve('unnullable_kind')
                l_2_field_maybe_mojom_type = resolve('field_maybe_mojom_type')
                l_2_name = l_2_kind = l_2_field_mojom_type = missing
                _loop_vars = {}
                pass
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                _loop_vars['name'] = l_2_name
                l_2_kind = environment.getattr(l_2_field, 'kind')
                _loop_vars['kind'] = l_2_kind
                l_2_field_mojom_type = t_3((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)
                _loop_vars['field_mojom_type'] = l_2_field_mojom_type
                t_20.extend((
                    '\n  ',
                    str((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                    ' local_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    '{',
                    str(t_4((undefined(name='kind') if l_2_kind is missing else l_2_kind))),
                    '};',
                ))
                if t_9((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    l_2_unnullable_kind = t_11((undefined(name='kind') if l_2_kind is missing else l_2_kind))
                    _loop_vars['unnullable_kind'] = l_2_unnullable_kind
                    l_2_field_maybe_mojom_type = t_3((undefined(name='unnullable_kind') if l_2_unnullable_kind is missing else l_2_unnullable_kind), add_same_module_namespaces=True)
                    _loop_vars['field_maybe_mojom_type'] = l_2_field_maybe_mojom_type
                    t_20.extend((
                        '\n  ',
                        str((undefined(name='field_maybe_mojom_type') if l_2_field_maybe_mojom_type is missing else l_2_field_maybe_mojom_type)),
                        ' local_maybe_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '{',
                        str(t_4((undefined(name='unnullable_kind') if l_2_unnullable_kind is missing else l_2_unnullable_kind))),
                        '};',
                    ))
            l_2_field = l_2_name = l_2_kind = l_2_field_mojom_type = l_2_unnullable_kind = l_2_field_maybe_mojom_type = missing
            for l_2_field in environment.getattr(l_1_struct, 'fields'):
                l_2_name = l_2_kind = missing
                _loop_vars = {}
                pass
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                _loop_vars['name'] = l_2_name
                l_2_kind = environment.getattr(l_2_field, 'kind')
                _loop_vars['kind'] = l_2_kind
                if (not t_9((undefined(name='kind') if l_2_kind is missing else l_2_kind))):
                    pass
                    t_20.extend((
                        '\n  mojolpm_result &= FromProto(input.m_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(), local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');',
                    ))
                else:
                    pass
                    t_20.extend((
                        '\n  if (input.has_m_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '() && FromProto(input.m_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(), local_maybe_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ')) {\n    local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ' = std::move(local_maybe_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n  }',
                    ))
            l_2_field = l_2_name = l_2_kind = missing
            t_20.extend((
                '\n  if (mojolpm_result) {\n    output = ',
                str(t_5(l_1_struct, flatten_nested_kind=True)),
                '::New(',
            ))
            l_2_loop = missing
            for l_2_field, l_2_loop in LoopContext(environment.getattr(l_1_struct, 'fields'), undefined):
                l_2_name = missing
                _loop_vars = {}
                pass
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                _loop_vars['name'] = l_2_name
                t_20.extend((
                    '\n      std::move(local_',
                    str((undefined(name='name') if l_2_name is missing else l_2_name)),
                    ')',
                    str((', ' if (not environment.getattr(l_2_loop, 'last')) else cond_expr_undefined("the inline if-expression on line 294 in 'mojolpm_from_proto_macros.tmpl' evaluated to false and no else section was defined."))),
                ))
            l_2_loop = l_2_field = l_2_name = missing
            t_20.append(
                ');\n  }\n\n  return mojolpm_result;',
            )
        else:
            pass
            t_20.extend((
                '\n  output = ',
                str(t_5(l_1_struct, flatten_nested_kind=True)),
                '::New();\n  return true;',
            ))
        t_20.extend((
            '\n}\n\nbool FromProto(\n    const ',
            str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
            '& input,\n    ',
            str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            '& output) {\n  if (input.instance_case() == ',
            str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
            '::kOld) {\n    ',
            str((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
            '* old = mojolpm::GetContext()->GetInstance<',
            str((undefined(name='struct_type') if l_1_struct_type is missing else l_1_struct_type)),
            '>(input.old());\n    if (old) {\n      return FromProto(*old, output);\n    }\n  } else {\n    return FromProto(input.new_(), output);\n  }\n\n  return false;\n}',
        ))
        return concat(t_20)
    context.exported_vars.add('define_struct')
    context.vars['define_struct'] = l_0_define_struct = Macro(environment, macro, 'define_struct', ('struct',), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_union):
        t_21 = []
        l_1_dataview_type = resolve('dataview_type')
        l_1_data_type = resolve('data_type')
        l_1_mojom_type = l_1_proto_type = l_1_union_type = missing
        if l_1_union is missing:
            l_1_union = undefined("parameter 'union' was not provided", name='union')
        pass
        l_1_mojom_type = t_2(l_1_union, add_same_module_namespaces=True)
        l_1_proto_type = str_join(('::mojolpm', t_5(l_1_union, flatten_nested_kind=True), ))
        l_1_union_type = str_join(((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type), '_ProtoUnion', ))
        t_21.extend((
            '\nbool FromProto(\n    const ',
            str((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
            '& input,\n    ',
            str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            '& output) {',
        ))
        if t_10(l_1_union):
            pass
            l_1_dataview_type = str_join((t_5(l_1_union, flatten_nested_kind=True), 'DataView', ))
            l_1_data_type = t_5(l_1_union, flatten_nested_kind=True, internal=True)
            t_21.extend((
                '\n  ::mojo::Message mojolpm_message(0, 0, 0, 0, nullptr);\n  ::mojo::internal::MessageFragment<',
                str((undefined(name='data_type') if l_1_data_type is missing else l_1_data_type)),
                '> mojolpm_fragment(\n      mojolpm_message);\n\n  ::mojo::internal::Serializer<',
                str((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
                ', const ',
                str((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
                '>::Serialize(\n    input, mojolpm_fragment, false);\n  return ::mojo::internal::Serializer<',
                str((undefined(name='dataview_type') if l_1_dataview_type is missing else l_1_dataview_type)),
                ', ',
                str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
                '>::Deserialize(\n    mojolpm_fragment.data(), &output, &mojolpm_message);',
            ))
        else:
            pass
            t_21.append(
                '\n  switch (input.union_member_case()) {',
            )
            for l_2_field in environment.getattr(l_1_union, 'fields'):
                l_2_unnullable_kind = resolve('unnullable_kind')
                l_2_field_maybe_mojom_type = resolve('field_maybe_mojom_type')
                l_2_name = l_2_kind = l_2_field_mojom_type = missing
                _loop_vars = {}
                pass
                l_2_name = t_1(environment.getattr(l_2_field, 'name'))
                _loop_vars['name'] = l_2_name
                l_2_kind = environment.getattr(l_2_field, 'kind')
                _loop_vars['kind'] = l_2_kind
                l_2_field_mojom_type = t_3((undefined(name='kind') if l_2_kind is missing else l_2_kind), add_same_module_namespaces=True)
                _loop_vars['field_mojom_type'] = l_2_field_mojom_type
                t_21.extend((
                    '\n    case ',
                    str((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
                    '::k',
                    str(t_12(str_join(('m_', (undefined(name='name') if l_2_name is missing else l_2_name), )))),
                    ': {',
                ))
                if t_9((undefined(name='kind') if l_2_kind is missing else l_2_kind)):
                    pass
                    l_2_unnullable_kind = t_11((undefined(name='kind') if l_2_kind is missing else l_2_kind))
                    _loop_vars['unnullable_kind'] = l_2_unnullable_kind
                    l_2_field_maybe_mojom_type = t_3((undefined(name='unnullable_kind') if l_2_unnullable_kind is missing else l_2_unnullable_kind), add_same_module_namespaces=True)
                    _loop_vars['field_maybe_mojom_type'] = l_2_field_maybe_mojom_type
                    t_21.extend((
                        '\n      ',
                        str((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                        ' local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '{',
                        str(t_4((undefined(name='kind') if l_2_kind is missing else l_2_kind))),
                        '};\n      ',
                        str((undefined(name='field_maybe_mojom_type') if l_2_field_maybe_mojom_type is missing else l_2_field_maybe_mojom_type)),
                        ' maybe_local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '{',
                        str(t_4((undefined(name='unnullable_kind') if l_2_unnullable_kind is missing else l_2_unnullable_kind))),
                        '};\n      if (FromProto(input.m_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(), maybe_local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ')) {\n        local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ' = std::move(maybe_local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ');\n      }\n      output = ',
                        str(t_5(l_1_union, flatten_nested_kind=True)),
                        '::New',
                        str(t_12((undefined(name='name') if l_2_name is missing else l_2_name), digits_split=False)),
                        '(std::move(local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '));\n      return true;',
                    ))
                else:
                    pass
                    t_21.extend((
                        '\n      ',
                        str((undefined(name='field_mojom_type') if l_2_field_mojom_type is missing else l_2_field_mojom_type)),
                        ' local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '{',
                        str(t_4((undefined(name='kind') if l_2_kind is missing else l_2_kind))),
                        '};\n      if (FromProto(input.m_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '(), local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        ')) {\n        output = ',
                        str(t_5(l_1_union, flatten_nested_kind=True)),
                        '::New',
                        str(t_12((undefined(name='name') if l_2_name is missing else l_2_name), digits_split=False)),
                        '(std::move(local_',
                        str((undefined(name='name') if l_2_name is missing else l_2_name)),
                        '));\n        return true;\n      }\n      break;',
                    ))
                t_21.append(
                    '\n    }\n',
                )
            l_2_field = l_2_name = l_2_kind = l_2_field_mojom_type = l_2_unnullable_kind = l_2_field_maybe_mojom_type = missing
            t_21.append(
                '\n    default: {\n      return false;\n    }\n  }\n\n  return false;',
            )
        t_21.extend((
            '\n}\n\nbool FromProto(\n    const ',
            str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
            '& input,\n    ',
            str((undefined(name='mojom_type') if l_1_mojom_type is missing else l_1_mojom_type)),
            '& output) {\n  if (input.instance_case() == ',
            str((undefined(name='proto_type') if l_1_proto_type is missing else l_1_proto_type)),
            '::kOld) {\n    ',
            str((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
            '* old = mojolpm::GetContext()->GetInstance<',
            str((undefined(name='union_type') if l_1_union_type is missing else l_1_union_type)),
            '>(input.old());\n    if (old) {\n      return FromProto(*old, output);\n    }\n  } else {\n    return FromProto(input.new_(), output);\n  }\n\n  return false;\n}',
        ))
        return concat(t_21)
    context.exported_vars.add('define_union')
    context.vars['define_union'] = l_0_define_union = Macro(environment, macro, 'define_union', ('union',), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=84&4=86&5=95&6=96&7=98&9=101&12=104&13=106&14=109&15=113&16=115&17=119&18=121&20=125&21=127&24=134&25=136&30=142&31=151&32=152&33=153&34=155&36=158&39=161&40=163&41=165&42=168&43=171&44=173&45=176&48=182&49=184&51=187&52=190&53=192&54=195&55=197&57=201&58=203&61=210&62=212&67=218&68=229&69=231&70=233&71=235&72=237&73=239&78=244&79=254&81=257&82=259&87=261&88=266&89=268&90=269&91=272&95=277&111=290&112=293&113=295&114=298&115=300&117=304&118=306&123=313&124=315&131=321&132=331&133=332&135=335&136=337&137=339&140=342&141=344&142=345&143=348&144=352&145=356&157=365&158=369&172=377&173=381&174=383&175=387&178=393&179=395&183=398&184=401&185=403&186=406&187=408&189=412&190=414&195=421&196=423&203=429&204=440&205=442&206=444&207=446&208=448&209=450&214=455&215=461&216=462&217=463&219=466&220=468&221=471&225=475&228=482&229=486&235=495&236=503&237=504&238=505&240=508&241=510&242=513&250=518&251=520&252=521&254=524&258=526&260=530&265=535&267=540&268=546&269=548&270=550&271=554&272=561&273=563&274=565&275=569&279=577&280=581&281=583&282=585&283=589&285=598&286=604&291=612&292=616&293=620&294=624&300=636&306=641&307=643&308=645&309=647&322=655&323=663&324=664&325=665&327=668&328=670&329=673&330=675&331=676&333=679&336=681&338=685&342=695&343=701&344=703&345=705&346=709&347=714&348=716&349=718&350=722&351=728&352=734&353=738&355=742&358=753&359=759&360=763&377=779&378=781&379=783&380=785'