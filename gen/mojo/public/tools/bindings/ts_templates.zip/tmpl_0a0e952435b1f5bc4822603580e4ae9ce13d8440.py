from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'struct_definition.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_generate_struct_deserializers = resolve('generate_struct_deserializers')
    l_0_enum_def = missing
    try:
        t_1 = environment.filters['constant_value']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'constant_value' found.")
    try:
        t_2 = environment.filters['default_ts_value']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'default_ts_value' found.")
    try:
        t_3 = environment.filters['is_bool_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'is_bool_kind' found.")
    try:
        t_4 = environment.filters['is_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_nullable_value_kind_packed_field' found.")
    try:
        t_5 = environment.filters['is_primary_nullable_value_kind_packed_field']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'is_primary_nullable_value_kind_packed_field' found.")
    try:
        t_6 = environment.filters['spec_type']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'spec_type' found.")
    try:
        t_7 = environment.filters['ts_type_maybe_nullable']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'ts_type_maybe_nullable' found.")
    pass
    for l_1_constant in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'constants'):
        _loop_vars = {}
        pass
        yield '\nexport const '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '_'
        yield str(environment.getattr(l_1_constant, 'name'))
        yield ': '
        yield str(t_7(environment.getattr(l_1_constant, 'kind')))
        yield ' =\n    '
        yield str(t_1(l_1_constant))
        yield ';\n'
    l_1_constant = missing
    included_template = environment.get_template('enum_definition.tmpl', 'struct_definition.tmpl').make_module(context.get_all(), True, {'enum_def': l_0_enum_def})
    l_0_enum_def = getattr(included_template, 'enum_def', missing)
    if l_0_enum_def is missing:
        l_0_enum_def = undefined(f"the template {included_template.__name__!r} (imported on line 6 in 'struct_definition.tmpl') does not export the requested name 'enum_def'", name='enum_def')
    context.vars['enum_def'] = l_0_enum_def
    context.exported_vars.discard('enum_def')
    yield '\n'
    for l_1_enum in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'enums'):
        _loop_vars = {}
        pass
        yield '\n'
        yield str(context.call((undefined(name='enum_def') if l_0_enum_def is missing else l_0_enum_def), l_1_enum, _loop_vars=_loop_vars))
        yield '\n'
    l_1_enum = missing
    yield '\n\nmojo.internal.Struct(\n    '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield "Spec.$,\n    '"
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield "',\n    ["
    for l_1_packed_field in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields_in_ordinal_order'):
        l_1_name = resolve('name')
        l_1_is_primary = resolve('is_primary')
        _loop_vars = {}
        pass
        yield "\n      mojo.internal.StructField(\n        '"
        yield str(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'name'))
        yield "', "
        yield str(environment.getattr(l_1_packed_field, 'offset'))
        yield ',\n        '
        if t_3(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')):
            pass
            yield str(environment.getattr(l_1_packed_field, 'bit'))
        else:
            pass
            yield '0'
        yield ',\n        '
        yield str(t_6(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind')))
        yield ',\n        '
        yield str(t_2(environment.getattr(l_1_packed_field, 'field')))
        yield ','
        if environment.getattr(environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'kind'), 'is_nullable'):
            pass
            yield '\n        true /* nullable */,'
        else:
            pass
            yield '\n        false /* nullable */,'
        yield '\n        '
        yield str((environment.getattr(environment.getattr(l_1_packed_field, 'field'), 'min_version') or 0))
        yield ','
        if t_4(l_1_packed_field):
            pass
            l_1_name = environment.getattr(environment.getattr(l_1_packed_field, 'original_field'), 'name')
            _loop_vars['name'] = l_1_name
            l_1_is_primary = t_5(l_1_packed_field)
            _loop_vars['is_primary'] = l_1_is_primary
            yield '\n        {'
            if (undefined(name='is_primary') if l_1_is_primary is missing else l_1_is_primary):
                pass
                yield '\n          isPrimary: true,\n          linkedValueFieldName: "'
                yield str(environment.getattr(environment.getattr(environment.getattr(l_1_packed_field, 'linked_value_packed_field'), 'field'), 'name'))
                yield '",'
            else:
                pass
                yield '\n          isPrimary: false,'
            yield '\n          originalFieldName: "'
            yield str((undefined(name='name') if l_1_name is missing else l_1_name))
            yield '",\n        }'
        yield '\n    ),'
    l_1_packed_field = l_1_name = l_1_is_primary = missing
    yield '\n    ],\n    ['
    for l_1_info in environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'versions'):
        _loop_vars = {}
        pass
        yield '['
        yield str(environment.getattr(l_1_info, 'version'))
        yield ', '
        yield str(environment.getattr(l_1_info, 'num_bytes'))
        yield '],'
    l_1_info = missing
    yield ']);\n\n'
    if (undefined(name='generate_struct_deserializers') if l_0_generate_struct_deserializers is missing else l_0_generate_struct_deserializers):
        pass
        yield '\nexport const '
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield '_Deserialize =\n    mojo.internal.createStructDeserializer('
        yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
        yield 'Spec.$);\n'
    yield '\n\nexport interface '
    yield str(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'))
    yield ' {'
    for l_1_packed_field in environment.getattr(environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'packed'), 'packed_fields'):
        l_1_original_field = resolve('original_field')
        l_1_name = resolve('name')
        l_1_kind = resolve('kind')
        l_1_f = resolve('f')
        _loop_vars = {}
        pass
        if t_4(l_1_packed_field):
            pass
            if t_5(l_1_packed_field):
                pass
                l_1_original_field = environment.getattr(l_1_packed_field, 'original_field')
                _loop_vars['original_field'] = l_1_original_field
                l_1_name = environment.getattr((undefined(name='original_field') if l_1_original_field is missing else l_1_original_field), 'name')
                _loop_vars['name'] = l_1_name
                l_1_kind = environment.getattr((undefined(name='original_field') if l_1_original_field is missing else l_1_original_field), 'kind')
                _loop_vars['kind'] = l_1_kind
                yield '\n  '
                yield str((undefined(name='name') if l_1_name is missing else l_1_name))
                yield ': '
                yield str(t_7((undefined(name='kind') if l_1_kind is missing else l_1_kind)))
                yield ';'
        else:
            pass
            yield '\n  '
            l_1_f = environment.getattr(l_1_packed_field, 'field')
            _loop_vars['f'] = l_1_f
            yield str(environment.getattr((undefined(name='f') if l_1_f is missing else l_1_f), 'name'))
            yield ': '
            yield str(t_7(environment.getattr((undefined(name='f') if l_1_f is missing else l_1_f), 'kind')))
            yield ';'
    l_1_packed_field = l_1_original_field = l_1_name = l_1_kind = l_1_f = missing
    yield '\n}'

blocks = {}
debug_info = '1=56&2=60&3=66&6=69&7=76&8=80&12=84&13=86&15=88&17=94&18=98&20=105&21=107&22=109&27=116&28=118&29=120&30=122&32=125&34=128&38=134&45=139&46=143&50=149&51=152&52=154&55=157&56=159&57=166&58=168&59=170&60=172&61=174&62=177&65=184&66=186'