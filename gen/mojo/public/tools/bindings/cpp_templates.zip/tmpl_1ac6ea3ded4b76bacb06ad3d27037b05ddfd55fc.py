from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'union_traits_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_union = resolve('union')
    l_0_export_attribute = resolve('export_attribute')
    l_0_mojom_type = missing
    try:
        t_1 = environment.filters['contains_handles_or_interfaces']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'contains_handles_or_interfaces' found.")
    try:
        t_2 = environment.filters['cpp_union_trait_getter_return_type']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_union_trait_getter_return_type' found.")
    try:
        t_3 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_4 = environment.filters['is_reference_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'is_reference_kind' found.")
    pass
    l_0_mojom_type = t_3((undefined(name='union') if l_0_union is missing else l_0_union))
    context.vars['mojom_type'] = l_0_mojom_type
    context.exported_vars.add('mojom_type')
    yield '\n\ntemplate <>\nstruct '
    yield str((undefined(name='export_attribute') if l_0_export_attribute is missing else l_0_export_attribute))
    yield ' UnionTraits<'
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::DataView,\n                                        '
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr> {\n  static bool IsNull(const '
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr& input) { return !input; }\n  static void SetToNull('
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr* output) { output->reset(); }\n\n  static '
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::Tag GetTag(const '
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr& input) {\n    return input->which();\n  }'
    for l_1_field in environment.getattr((undefined(name='union') if l_0_union is missing else l_0_union), 'fields'):
        l_1_maybe_const_in = l_1_maybe_const_out = missing
        _loop_vars = {}
        pass
        l_1_maybe_const_in = ('' if t_1(environment.getattr(l_1_field, 'kind')) else 'const')
        _loop_vars['maybe_const_in'] = l_1_maybe_const_in
        l_1_maybe_const_out = ('' if (t_1(environment.getattr(l_1_field, 'kind')) or (not t_4(environment.getattr(l_1_field, 'kind')))) else 'const')
        _loop_vars['maybe_const_out'] = l_1_maybe_const_out
        yield '\n\n  static '
        yield str((undefined(name='maybe_const_out') if l_1_maybe_const_out is missing else l_1_maybe_const_out))
        yield ' '
        yield str(t_2(environment.getattr(l_1_field, 'kind')))
        yield ' '
        yield str(environment.getattr(l_1_field, 'name'))
        yield '('
        yield str((undefined(name='maybe_const_in') if l_1_maybe_const_in is missing else l_1_maybe_const_in))
        yield ' '
        yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
        yield 'Ptr& input) {\n    return input->get_'
        yield str(environment.getattr(l_1_field, 'name'))
        yield '();\n  }'
    l_1_field = l_1_maybe_const_in = l_1_maybe_const_out = missing
    yield '\n\n  static bool Read('
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield '::DataView input, '
    yield str((undefined(name='mojom_type') if l_0_mojom_type is missing else l_0_mojom_type))
    yield 'Ptr* output);\n};'

blocks = {}
debug_info = '1=38&4=42&5=46&6=48&7=50&9=52&13=56&14=60&15=62&18=65&19=75&23=79'