from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'struct_serialization_declaration.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct = resolve('struct')
    l_0_struct_macros = l_0_data_view = l_0_data_type = missing
    try:
        t_1 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_2 = environment.filters['indent']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'indent' found.")
    try:
        t_3 = environment.filters['use_custom_serializer']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'use_custom_serializer' found.")
    pass
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'struct_serialization_declaration.tmpl')._get_default_module(context)
    context.exported_vars.discard('struct_macros')
    l_0_data_view = str_join((t_1((undefined(name='struct') if l_0_struct is missing else l_0_struct)), 'DataView', ))
    context.vars['data_view'] = l_0_data_view
    context.exported_vars.add('data_view')
    l_0_data_type = t_1((undefined(name='struct') if l_0_struct is missing else l_0_struct), internal=True)
    context.vars['data_type'] = l_0_data_type
    context.exported_vars.add('data_type')
    if (not t_3((undefined(name='struct') if l_0_struct is missing else l_0_struct))):
        pass
        yield '\n\nnamespace internal {\n\ntemplate <typename MaybeConstUserType>\nstruct Serializer<'
        yield str((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
        yield ', MaybeConstUserType> {\n  using UserType = typename std::remove_const<MaybeConstUserType>::type;\n  using Traits = StructTraits<'
        yield str((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
        yield ', UserType>;\n\n  static void Serialize(\n      MaybeConstUserType& input,\n      mojo::internal::MessageFragment<'
        yield str((undefined(name='data_type') if l_0_data_type is missing else l_0_data_type))
        yield '>& fragment) {\n    if (CallIsNullIfExists<Traits>(input))\n      return;\n    '
        yield str(t_2(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'serialize'), (undefined(name='struct') if l_0_struct is missing else l_0_struct), str_join((environment.getattr((undefined(name='struct') if l_0_struct is missing else l_0_struct), 'name'), ' struct', )), 'Traits::%s(input)', 'fragment', True), 2))
        yield '\n  }\n\n  static bool Deserialize('
        yield str((undefined(name='data_type') if l_0_data_type is missing else l_0_data_type))
        yield '* input,\n                          UserType* output,\n                          Message* message) {\n    if (!input)\n      return CallSetToNullIfExists<Traits>(output);\n\n    '
        yield str((undefined(name='data_view') if l_0_data_view is missing else l_0_data_view))
        yield ' data_view(input, message);\n    return Traits::Read(data_view, output);\n  }\n};\n\n}  // namespace internal'

blocks = {}
debug_info = '1=31&2=33&3=36&5=39&10=42&12=44&16=46&21=48&24=50&30=52'