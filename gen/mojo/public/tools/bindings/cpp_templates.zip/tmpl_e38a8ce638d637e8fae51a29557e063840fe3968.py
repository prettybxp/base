from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'interface_macros.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_struct_macros = l_0_declare_params = l_0_declare_callback = l_0_declare_request_params = l_0_trace_event = l_0_declare_sync_method_params = l_0_build_message_flags = l_0_build_serialized_message = l_0_define_message_type = missing
    try:
        t_1 = environment.filters['cpp_wrapper_call_type']
    except KeyError:
        @internalcode
        def t_1(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_call_type' found.")
    try:
        t_2 = environment.filters['cpp_wrapper_param_type']
    except KeyError:
        @internalcode
        def t_2(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_param_type' found.")
    try:
        t_3 = environment.filters['cpp_wrapper_type']
    except KeyError:
        @internalcode
        def t_3(*unused):
            raise TemplateRuntimeError("No filter named 'cpp_wrapper_type' found.")
    try:
        t_4 = environment.filters['get_name_for_kind']
    except KeyError:
        @internalcode
        def t_4(*unused):
            raise TemplateRuntimeError("No filter named 'get_name_for_kind' found.")
    try:
        t_5 = environment.filters['get_qualified_name_for_kind']
    except KeyError:
        @internalcode
        def t_5(*unused):
            raise TemplateRuntimeError("No filter named 'get_qualified_name_for_kind' found.")
    try:
        t_6 = environment.filters['is_interface_kind']
    except KeyError:
        @internalcode
        def t_6(*unused):
            raise TemplateRuntimeError("No filter named 'is_interface_kind' found.")
    try:
        t_7 = environment.filters['is_receiver_kind']
    except KeyError:
        @internalcode
        def t_7(*unused):
            raise TemplateRuntimeError("No filter named 'is_receiver_kind' found.")
    pass
    l_0_struct_macros = context.vars['struct_macros'] = environment.get_template('struct_macros.tmpl', 'interface_macros.tmpl')._get_default_module(context)
    context.exported_vars.discard('struct_macros')
    def macro(l_1_prefix, l_1_parameters):
        t_8 = []
        if l_1_prefix is missing:
            l_1_prefix = undefined("parameter 'prefix' was not provided", name='prefix')
        if l_1_parameters is missing:
            l_1_parameters = undefined("parameter 'parameters' was not provided", name='parameters')
        pass
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(l_1_parameters, undefined):
            _loop_vars = {}
            pass
            t_8.extend((
                str(t_2(environment.getattr(l_2_param, 'kind'))),
                ' ',
                str(l_1_prefix),
                str(environment.getattr(l_2_param, 'name')),
            ))
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_8.append(
                    ', ',
                )
        l_2_loop = l_2_param = missing
        return concat(t_8)
    context.exported_vars.add('declare_params')
    context.vars['declare_params'] = l_0_declare_params = Macro(environment, macro, 'declare_params', ('prefix', 'parameters'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_method, l_1_for_blink):
        t_9 = []
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        if l_1_for_blink is missing:
            l_1_for_blink = undefined("parameter 'for_blink' was not provided", name='for_blink')
        pass
        t_9.append(
            'base::OnceCallback<void(',
        )
        l_2_loop = missing
        for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'response_parameters'), undefined):
            _loop_vars = {}
            pass
            t_9.append(
                str(t_2(environment.getattr(l_2_param, 'kind'))),
            )
            if (not environment.getattr(l_2_loop, 'last')):
                pass
                t_9.append(
                    ', ',
                )
        l_2_loop = l_2_param = missing
        t_9.append(
            ')>',
        )
        return concat(t_9)
    context.exported_vars.add('declare_callback')
    context.vars['declare_callback'] = l_0_declare_callback = Macro(environment, macro, 'declare_callback', ('method', 'for_blink'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_prefix, l_1_method):
        t_10 = []
        if l_1_prefix is missing:
            l_1_prefix = undefined("parameter 'prefix' was not provided", name='prefix')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        t_10.append(
            str(context.call((undefined(name='declare_params') if l_0_declare_params is missing else l_0_declare_params), l_1_prefix, environment.getattr(l_1_method, 'parameters'))),
        )
        if (environment.getattr(l_1_method, 'response_parameters') != None):
            pass
            if environment.getattr(l_1_method, 'parameters'):
                pass
                t_10.append(
                    ', ',
                )
            t_10.extend((
                str(environment.getattr(l_1_method, 'name')),
                'Callback callback',
            ))
        return concat(t_10)
    context.exported_vars.add('declare_request_params')
    context.vars['declare_request_params'] = l_0_declare_request_params = Macro(environment, macro, 'declare_request_params', ('prefix', 'method'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_prefix, l_1_method_parameters, l_1_method_name, l_1_parameter_group, l_1_trace_event_type, l_1_dereference_parameters):
        t_11 = []
        if l_1_prefix is missing:
            l_1_prefix = undefined("parameter 'prefix' was not provided", name='prefix')
        if l_1_method_parameters is missing:
            l_1_method_parameters = undefined("parameter 'method_parameters' was not provided", name='method_parameters')
        if l_1_method_name is missing:
            l_1_method_name = undefined("parameter 'method_name' was not provided", name='method_name')
        if l_1_parameter_group is missing:
            l_1_parameter_group = undefined("parameter 'parameter_group' was not provided", name='parameter_group')
        if l_1_trace_event_type is missing:
            l_1_trace_event_type = ''
        if l_1_dereference_parameters is missing:
            l_1_dereference_parameters = False
        pass
        if l_1_method_parameters:
            pass
            t_11.extend((
                'TRACE_EVENT',
                str(l_1_trace_event_type),
                '1(\n    "mojom", "',
                str(l_1_method_name),
                '", "',
                str(l_1_parameter_group),
                '",\n    [&](perfetto::TracedValue context){\n      auto dict = std::move(context).WriteDictionary();',
            ))
            for l_2_param in l_1_method_parameters:
                _loop_vars = {}
                pass
                t_11.extend((
                    '\n      perfetto::WriteIntoTracedValueWithFallback(\n           dict.AddItem("',
                    str(environment.getattr(l_2_param, 'name')),
                    '"), ',
                    str((l_1_prefix + environment.getattr(l_2_param, 'name'))),
                    ',\n                        "<value of type ',
                    str(t_2(environment.getattr(l_2_param, 'kind'))),
                    '>");',
                ))
            l_2_param = missing
            t_11.append(
                '\n   });',
            )
        else:
            pass
            t_11.extend((
                'TRACE_EVENT',
                str(l_1_trace_event_type),
                '0("mojom", "',
                str(l_1_method_name),
                '");',
            ))
        return concat(t_11)
    context.exported_vars.add('trace_event')
    context.vars['trace_event'] = l_0_trace_event = Macro(environment, macro, 'trace_event', ('prefix', 'method_parameters', 'method_name', 'parameter_group', 'trace_event_type', 'dereference_parameters'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_prefix, l_1_method):
        t_12 = []
        if l_1_prefix is missing:
            l_1_prefix = undefined("parameter 'prefix' was not provided", name='prefix')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        pass
        t_12.append(
            str(context.call((undefined(name='declare_params') if l_0_declare_params is missing else l_0_declare_params), l_1_prefix, environment.getattr(l_1_method, 'parameters'))),
        )
        if environment.getattr(l_1_method, 'response_parameters'):
            pass
            if environment.getattr(l_1_method, 'parameters'):
                pass
                t_12.append(
                    ', ',
                )
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(environment.getattr(l_1_method, 'response_parameters'), undefined):
                _loop_vars = {}
                pass
                t_12.extend((
                    str(t_1(environment.getattr(l_2_param, 'kind'))),
                    '* out_',
                    str(l_1_prefix),
                    str(environment.getattr(l_2_param, 'name')),
                ))
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    t_12.append(
                        ', ',
                    )
            l_2_loop = l_2_param = missing
        return concat(t_12)
    context.exported_vars.add('declare_sync_method_params')
    context.vars['declare_sync_method_params'] = l_0_declare_sync_method_params = Macro(environment, macro, 'declare_sync_method_params', ('prefix', 'method'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_is_response, l_1_is_sync_text, l_1_allow_interrupt_text, l_1_is_urgent_text, l_1_expects_response_text, l_1_flags_name):
        t_13 = []
        if l_1_is_response is missing:
            l_1_is_response = undefined("parameter 'is_response' was not provided", name='is_response')
        if l_1_is_sync_text is missing:
            l_1_is_sync_text = undefined("parameter 'is_sync_text' was not provided", name='is_sync_text')
        if l_1_allow_interrupt_text is missing:
            l_1_allow_interrupt_text = undefined("parameter 'allow_interrupt_text' was not provided", name='allow_interrupt_text')
        if l_1_is_urgent_text is missing:
            l_1_is_urgent_text = undefined("parameter 'is_urgent_text' was not provided", name='is_urgent_text')
        if l_1_expects_response_text is missing:
            l_1_expects_response_text = undefined("parameter 'expects_response_text' was not provided", name='expects_response_text')
        if l_1_flags_name is missing:
            l_1_flags_name = undefined("parameter 'flags_name' was not provided", name='flags_name')
        pass
        if l_1_is_response:
            pass
            t_13.extend((
                '\n  const uint32_t kFlags = mojo::Message::kFlagIsResponse |\n      ((',
                str(l_1_is_sync_text),
                ') ? mojo::Message::kFlagIsSync : 0) |\n      ((',
                str(l_1_allow_interrupt_text),
                ') ? 0 : mojo::Message::kFlagNoInterrupt) |\n      ((',
                str(l_1_is_urgent_text),
                ') ? mojo::Message::kFlagIsUrgent : 0);',
            ))
        else:
            pass
            t_13.extend((
                '\n  const uint32_t kFlags =\n      ((',
                str(l_1_expects_response_text),
                ') ? mojo::Message::kFlagExpectsResponse : 0) |\n      ((',
                str(l_1_is_sync_text),
                ') ? mojo::Message::kFlagIsSync : 0) |\n      ((',
                str(l_1_allow_interrupt_text),
                ') ? 0 : mojo::Message::kFlagNoInterrupt) |\n      ((',
                str(l_1_is_urgent_text),
                ') ? mojo::Message::kFlagIsUrgent : 0);',
            ))
        return concat(t_13)
    context.exported_vars.add('build_message_flags')
    context.vars['build_message_flags'] = l_0_build_message_flags = Macro(environment, macro, 'build_message_flags', ('is_response', 'is_sync_text', 'allow_interrupt_text', 'is_urgent_text', 'expects_response_text', 'flags_name'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_message_name, l_1_method, l_1_param_name_prefix, l_1_params_struct, l_1_params_description, l_1_flags_text, l_1_message_object_name, l_1_has_size_estimator):
        t_14 = []
        if l_1_message_name is missing:
            l_1_message_name = undefined("parameter 'message_name' was not provided", name='message_name')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        if l_1_param_name_prefix is missing:
            l_1_param_name_prefix = undefined("parameter 'param_name_prefix' was not provided", name='param_name_prefix')
        if l_1_params_struct is missing:
            l_1_params_struct = undefined("parameter 'params_struct' was not provided", name='params_struct')
        if l_1_params_description is missing:
            l_1_params_description = undefined("parameter 'params_description' was not provided", name='params_description')
        if l_1_flags_text is missing:
            l_1_flags_text = undefined("parameter 'flags_text' was not provided", name='flags_text')
        if l_1_message_object_name is missing:
            l_1_message_object_name = undefined("parameter 'message_object_name' was not provided", name='message_object_name')
        if l_1_has_size_estimator is missing:
            l_1_has_size_estimator = False
        pass
        t_14.append(
            '\n  const size_t estimated_payload_size =',
        )
        if (l_1_has_size_estimator and environment.getattr(l_1_method, 'estimate_message_size')):
            pass
            t_14.extend((
                '\n    size_estimator_.EstimatePayloadSize(',
                str(l_1_message_name),
                ');',
            ))
        else:
            pass
            t_14.append(
                '\n    0;',
            )
        if environment.getattr(l_1_method, 'unlimited_message_size'):
            pass
            t_14.extend((
                '\n  mojo::Message ',
                str(l_1_message_object_name),
                '(\n      ',
                str(l_1_message_name),
                ', ',
                str(l_1_flags_text),
                ',\n      MOJO_CREATE_MESSAGE_FLAG_UNLIMITED_SIZE,\n      estimated_payload_size);',
            ))
        else:
            pass
            t_14.extend((
                '\n  mojo::Message ',
                str(l_1_message_object_name),
                '(\n      ',
                str(l_1_message_name),
                ', ',
                str(l_1_flags_text),
                ', estimated_payload_size);',
            ))
        t_14.extend((
            '\n  mojo::internal::MessageFragment<\n      ',
            str(t_5(l_1_params_struct, internal=True)),
            '> params(\n          ',
            str(l_1_message_object_name),
            ');\n  ',
            str(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'serialize'), l_1_params_struct, l_1_params_description, l_1_param_name_prefix, 'params')),
        ))
        return concat(t_14)
    context.exported_vars.add('build_serialized_message')
    context.vars['build_serialized_message'] = l_0_build_serialized_message = Macro(environment, macro, 'build_serialized_message', ('message_name', 'method', 'param_name_prefix', 'params_struct', 'params_description', 'flags_text', 'message_object_name', 'has_size_estimator'), False, False, False, context.eval_ctx.autoescape)
    def macro(l_1_interface, l_1_message_typename, l_1_message_name, l_1_is_response, l_1_method, l_1_parameters, l_1_params_struct, l_1_params_description):
        t_15 = []
        if l_1_interface is missing:
            l_1_interface = undefined("parameter 'interface' was not provided", name='interface')
        if l_1_message_typename is missing:
            l_1_message_typename = undefined("parameter 'message_typename' was not provided", name='message_typename')
        if l_1_message_name is missing:
            l_1_message_name = undefined("parameter 'message_name' was not provided", name='message_name')
        if l_1_is_response is missing:
            l_1_is_response = undefined("parameter 'is_response' was not provided", name='is_response')
        if l_1_method is missing:
            l_1_method = undefined("parameter 'method' was not provided", name='method')
        if l_1_parameters is missing:
            l_1_parameters = undefined("parameter 'parameters' was not provided", name='parameters')
        if l_1_params_struct is missing:
            l_1_params_struct = undefined("parameter 'params_struct' was not provided", name='params_struct')
        if l_1_params_description is missing:
            l_1_params_description = undefined("parameter 'params_description' was not provided", name='params_description')
        pass
        t_15.extend((
            'class ',
            str(l_1_message_typename),
            '\n    : public mojo::internal::UnserializedMessageContext {\n public:\n  static const mojo::internal::UnserializedMessageContext::Tag kMessageTag;\n\n  explicit ',
            str(l_1_message_typename),
            '(\n      uint32_t message_flags',
        ))
        for l_2_param in l_1_parameters:
            _loop_vars = {}
            pass
            t_15.extend((
                '\n      , ',
                str(t_2(environment.getattr(l_2_param, 'kind'))),
                ' param_',
                str(environment.getattr(l_2_param, 'name')),
            ))
        l_2_param = missing
        t_15.extend((
            '\n  )\n      : mojo::internal::UnserializedMessageContext(\n          &kMessageTag,\n          ',
            str(l_1_message_name),
            ',\n          message_flags)',
        ))
        for l_2_param in l_1_parameters:
            _loop_vars = {}
            pass
            if t_6(environment.getattr(l_2_param, 'kind')):
                pass
                t_15.extend((
                    '\n      , param_',
                    str(environment.getattr(l_2_param, 'name')),
                    '_(param_',
                    str(environment.getattr(l_2_param, 'name')),
                    '.PassInterface())',
                ))
            else:
                pass
                t_15.extend((
                    '\n      , param_',
                    str(environment.getattr(l_2_param, 'name')),
                    '_(std::move(param_',
                    str(environment.getattr(l_2_param, 'name')),
                    '))',
                ))
        l_2_param = missing
        t_15.extend((
            '{}\n\n  ',
            str(l_1_message_typename),
            '(const ',
            str(l_1_message_typename),
            '&) = delete;\n  ',
            str(l_1_message_typename),
            '& operator=(const ',
            str(l_1_message_typename),
            '&) = delete;\n\n  ~',
            str(l_1_message_typename),
            '() override = default;\n\n  static mojo::Message Build(\n      bool serialize,',
        ))
        if (not l_1_is_response):
            pass
            t_15.append(
                '\n      bool expects_response,',
            )
        t_15.append(
            '\n      bool is_sync,\n      bool allow_interrupt,\n      bool is_urgent',
        )
        if l_1_parameters:
            pass
            t_15.extend((
                ',\n      ',
                str(context.call((undefined(name='declare_params') if l_0_declare_params is missing else l_0_declare_params), 'param_', l_1_parameters)),
            ))
        t_15.extend((
            ') {\n\n    ',
            str(context.call((undefined(name='build_message_flags') if l_0_build_message_flags is missing else l_0_build_message_flags), l_1_is_response, 'is_sync', 'allow_interrupt', 'is_urgent', 'expects_response', 'kFlags')),
            '\n\n    if (!serialize) {\n      return mojo::Message(std::make_unique<',
            str(l_1_message_typename),
            '>(\n          kFlags',
        ))
        for l_2_param in l_1_parameters:
            _loop_vars = {}
            pass
            t_15.extend((
                '\n          , std::move(param_',
                str(environment.getattr(l_2_param, 'name')),
                ')',
            ))
        l_2_param = missing
        t_15.append(
            '\n          ),',
        )
        if environment.getattr(l_1_method, 'unlimited_message_size'):
            pass
            t_15.append(
                '\n          MOJO_CREATE_MESSAGE_FLAG_UNLIMITED_SIZE);',
            )
        else:
            pass
            t_15.append(
                '\n          MOJO_CREATE_MESSAGE_FLAG_NONE);',
            )
        t_15.extend((
            '\n    }\n\n    DCHECK(serialize);\n    ',
            str(context.call((undefined(name='build_serialized_message') if l_0_build_serialized_message is missing else l_0_build_serialized_message), l_1_message_name, l_1_method, 'param_%s', l_1_params_struct, l_1_params_description, 'kFlags', 'message')),
            '\n    return message;\n  }\n\n',
        ))
        if (not l_1_is_response):
            pass
            t_15.extend((
                '\n  void Dispatch(\n      mojo::Message* message,\n      ',
                str(environment.getattr(l_1_interface, 'name')),
                '* impl',
            ))
            if (environment.getattr(l_1_method, 'response_parameters') != None):
                pass
                t_15.extend((
                    ', ',
                    str(environment.getattr(l_1_interface, 'name')),
                    '::',
                    str(environment.getattr(l_1_method, 'name')),
                    'Callback callback',
                ))
            t_15.append(
                ') {\n    if (message->receiver_connection_group()) {',
            )
            for l_2_param in l_1_parameters:
                _loop_vars = {}
                pass
                if t_7(environment.getattr(l_2_param, 'kind')):
                    pass
                    t_15.extend((
                        '\n      param_',
                        str(environment.getattr(l_2_param, 'name')),
                        '_.set_connection_group(\n          *message->receiver_connection_group());',
                    ))
            l_2_param = missing
            t_15.extend((
                '\n    }\n\n    impl->',
                str(environment.getattr(l_1_method, 'name')),
                '(',
            ))
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(l_1_parameters, undefined):
                _loop_vars = {}
                pass
                if t_6(environment.getattr(l_2_param, 'kind')):
                    pass
                    t_15.extend((
                        '\n        ',
                        str(t_4(environment.getattr(l_2_param, 'kind'))),
                        'Ptr(std::move(param_',
                        str(environment.getattr(l_2_param, 'name')),
                        '_))',
                    ))
                else:
                    pass
                    t_15.extend((
                        '\n        std::move(param_',
                        str(environment.getattr(l_2_param, 'name')),
                        '_)',
                    ))
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    t_15.append(
                        ',',
                    )
            l_2_loop = l_2_param = missing
            if (environment.getattr(l_1_method, 'response_parameters') != None):
                pass
                if l_1_parameters:
                    pass
                    t_15.append(
                        ', ',
                    )
                t_15.append(
                    'std::move(callback)',
                )
            t_15.append(
                ');\n  }',
            )
        else:
            pass
            t_15.extend((
                '\n  void Dispatch(mojo::Message* message,\n                ',
                str(environment.getattr(l_1_interface, 'name')),
                '::',
                str(environment.getattr(l_1_method, 'name')),
                'Callback* callback) {\n    if (message->receiver_connection_group()) {',
            ))
            for l_2_param in l_1_parameters:
                _loop_vars = {}
                pass
                if t_7(environment.getattr(l_2_param, 'kind')):
                    pass
                    t_15.extend((
                        '\n      param_',
                        str(environment.getattr(l_2_param, 'name')),
                        '_.set_connection_group(\n          *message->receiver_connection_group());',
                    ))
            l_2_param = missing
            t_15.append(
                '\n    }\n\n    std::move(*callback).Run(',
            )
            l_2_loop = missing
            for l_2_param, l_2_loop in LoopContext(l_1_parameters, undefined):
                _loop_vars = {}
                pass
                if t_6(environment.getattr(l_2_param, 'kind')):
                    pass
                    t_15.extend((
                        '\n        ',
                        str(t_4(environment.getattr(l_2_param, 'kind'))),
                        'Ptr(std::move(param_',
                        str(environment.getattr(l_2_param, 'name')),
                        '_))',
                    ))
                else:
                    pass
                    t_15.extend((
                        '\n        std::move(param_',
                        str(environment.getattr(l_2_param, 'name')),
                        '_)',
                    ))
                if (not environment.getattr(l_2_loop, 'last')):
                    pass
                    t_15.append(
                        ', ',
                    )
            l_2_loop = l_2_param = missing
            t_15.append(
                ');\n  }\n\n',
            )
            if environment.getattr(l_1_method, 'sync'):
                pass
                t_15.append(
                    '\n  void HandleSyncResponse(\n      mojo::Message* message\n',
                )
                for l_2_param in l_1_parameters:
                    _loop_vars = {}
                    pass
                    t_15.extend((
                        ',\n      ',
                        str(t_1(environment.getattr(l_2_param, 'kind'))),
                        '* out_',
                        str(environment.getattr(l_2_param, 'name')),
                    ))
                l_2_param = missing
                t_15.append(
                    ') {\n\n    if (message->receiver_connection_group()) {',
                )
                for l_2_param in l_1_parameters:
                    _loop_vars = {}
                    pass
                    if t_7(environment.getattr(l_2_param, 'kind')):
                        pass
                        t_15.extend((
                            '\n      param_',
                            str(environment.getattr(l_2_param, 'name')),
                            '_.set_connection_group(\n          *message->receiver_connection_group());',
                        ))
                l_2_param = missing
                t_15.append(
                    '\n    }\n\n',
                )
                for l_2_param in l_1_parameters:
                    _loop_vars = {}
                    pass
                    if t_6(environment.getattr(l_2_param, 'kind')):
                        pass
                        t_15.extend((
                            '\n    out_',
                            str(environment.getattr(l_2_param, 'name')),
                            '->Bind(std::move(param_',
                            str(environment.getattr(l_2_param, 'name')),
                            '_));',
                        ))
                    else:
                        pass
                        t_15.extend((
                            '\n    *out_',
                            str(environment.getattr(l_2_param, 'name')),
                            ' = std::move(param_',
                            str(environment.getattr(l_2_param, 'name')),
                            '_);',
                        ))
                    t_15.append(
                        '\n',
                    )
                l_2_param = missing
                t_15.append(
                    '\n  }',
                )
        t_15.extend((
            '\n\n private:\n  // mojo::internal::UnserializedMessageContext:\n  void Serialize(mojo::Message& message) override {\n    mojo::internal::MessageFragment<\n        ',
            str(t_5(l_1_params_struct, internal=True)),
            '> params(\n            message);\n    ',
            str(context.call(environment.getattr((undefined(name='struct_macros') if l_0_struct_macros is missing else l_0_struct_macros), 'serialize'), l_1_params_struct, l_1_params_description, 'param_%s_', 'params')),
            '\n  }',
        ))
        for l_2_param in l_1_parameters:
            _loop_vars = {}
            pass
            t_15.extend((
                '\n  ',
                str(t_3(environment.getattr(l_2_param, 'kind'))),
                ' param_',
                str(environment.getattr(l_2_param, 'name')),
                '_;',
            ))
        l_2_param = missing
        t_15.extend((
            '\n};\n\nconst mojo::internal::UnserializedMessageContext::Tag\n',
            str(l_1_message_typename),
            '::kMessageTag = {};',
        ))
        return concat(t_15)
    context.exported_vars.add('define_message_type')
    context.vars['define_message_type'] = l_0_define_message_type = Macro(environment, macro, 'define_message_type', ('interface', 'message_typename', 'message_name', 'is_response', 'method', 'parameters', 'params_struct', 'params_description'), False, False, False, context.eval_ctx.autoescape)

blocks = {}
debug_info = '1=54&3=56&4=64&5=68&6=73&10=82&12=93&13=97&14=99&19=111&20=119&21=121&22=123&23=129&27=135&41=150&42=154&43=156&46=161&48=166&49=170&53=181&57=189&58=197&59=199&60=201&61=207&62=211&63=216&68=225&70=240&72=244&73=246&74=248&77=255&78=257&79=259&80=261&84=267&89=289&90=293&95=301&96=305&97=307&101=316&102=318&105=325&106=327&107=329&111=334&114=355&119=357&121=360&122=365&127=372&129=375&130=378&131=382&133=391&137=399&138=403&140=407&144=410&150=418&152=422&155=426&159=428&161=431&162=436&165=443&173=455&178=458&181=462&182=465&183=469&186=477&187=480&188=484&194=490&195=494&196=497&197=501&199=510&201=513&203=519&204=521&209=536&211=541&212=544&213=548&220=556&221=559&222=563&224=572&226=575&230=584&233=589&234=594&238=602&239=605&240=609&246=616&247=619&248=623&250=632&261=646&263=648&267=651&268=656&273=664'