from jinja2.runtime import LoopContext, Macro, Markup, Namespace, TemplateNotFound, TemplateReference, TemplateRuntimeError, Undefined, escape, identity, internalcode, markup_join, missing, str_join
name = 'module-features.h.tmpl'

def root(context, missing=missing):
    resolve = context.resolve_or_missing
    undefined = environment.undefined
    concat = environment.concat
    cond_expr_undefined = Undefined
    if 0: yield None
    l_0_module = resolve('module')
    l_0_export_header = resolve('export_header')
    l_0_enable_kythe_annotations = resolve('enable_kythe_annotations')
    l_0_namespaces_as_array = resolve('namespaces_as_array')
    l_0_features = resolve('features')
    l_0_include_guard = l_0_namespace_begin = l_0_namespace_end = l_0_variant_path = l_0_header_guard = l_0_kythe_annotation = missing
    pass
    yield '// Copyright 2023 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.'
    included_template = environment.get_template('cpp_macros.tmpl', 'module-features.h.tmpl')._get_default_module(context)
    l_0_include_guard = getattr(included_template, 'include_guard', missing)
    if l_0_include_guard is missing:
        l_0_include_guard = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-features.h.tmpl') does not export the requested name 'include_guard'", name='include_guard')
    l_0_namespace_begin = getattr(included_template, 'namespace_begin', missing)
    if l_0_namespace_begin is missing:
        l_0_namespace_begin = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-features.h.tmpl') does not export the requested name 'namespace_begin'", name='namespace_begin')
    l_0_namespace_end = getattr(included_template, 'namespace_end', missing)
    if l_0_namespace_end is missing:
        l_0_namespace_end = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-features.h.tmpl') does not export the requested name 'namespace_end'", name='namespace_end')
    l_0_variant_path = getattr(included_template, 'variant_path', missing)
    if l_0_variant_path is missing:
        l_0_variant_path = undefined(f"the template {included_template.__name__!r} (imported on line 5 in 'module-features.h.tmpl') does not export the requested name 'variant_path'", name='variant_path')
    context.vars.update({'include_guard': l_0_include_guard, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})
    context.exported_vars.difference_update(('include_guard', 'namespace_begin', 'namespace_end', 'variant_path'))
    l_0_header_guard = context.call((undefined(name='include_guard') if l_0_include_guard is missing else l_0_include_guard), 'FEATURES', environment.getattr((undefined(name='module') if l_0_module is missing else l_0_module), 'path'))
    context.vars['header_guard'] = l_0_header_guard
    context.exported_vars.add('header_guard')
    def macro(l_1_name):
        t_1 = []
        if l_1_name is missing:
            l_1_name = undefined("parameter 'name' was not provided", name='name')
        pass
        if (undefined(name='enable_kythe_annotations') if l_0_enable_kythe_annotations is missing else l_0_enable_kythe_annotations):
            pass
            t_1.extend((
                '\n// @generated_from: ',
                str(l_1_name),
            ))
        return concat(t_1)
    context.exported_vars.add('kythe_annotation')
    context.vars['kythe_annotation'] = l_0_kythe_annotation = Macro(environment, macro, 'kythe_annotation', ('name',), False, False, False, context.eval_ctx.autoescape)
    yield '\n\n#ifndef '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n#define '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))
    yield '\n\n#include "base/feature_list.h"\n#include "mojo/public/cpp/bindings/runtime_features.h"'
    if (undefined(name='export_header') if l_0_export_header is missing else l_0_export_header):
        pass
        yield '\n#include "'
        yield str((undefined(name='export_header') if l_0_export_header is missing else l_0_export_header))
        yield '"'
    yield '\n\n'
    if (undefined(name='enable_kythe_annotations') if l_0_enable_kythe_annotations is missing else l_0_enable_kythe_annotations):
        pass
        yield '#ifdef KYTHE_IS_RUNNING\n#pragma kythe_inline_metadata "Metadata comment"\n#endif'
    yield '\n\n'
    yield str(context.call((undefined(name='namespace_begin') if l_0_namespace_begin is missing else l_0_namespace_begin), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)))
    for l_1_feature in (undefined(name='features') if l_0_features is missing else l_0_features):
        _loop_vars = {}
        pass
        yield '\n'
        template = environment.get_template('feature_declaration.tmpl', 'module-features.h.tmpl')
        for event in template.root_render_func(template.new_context(context.get_all(), True, {'feature': l_1_feature, 'header_guard': l_0_header_guard, 'include_guard': l_0_include_guard, 'kythe_annotation': l_0_kythe_annotation, 'namespace_begin': l_0_namespace_begin, 'namespace_end': l_0_namespace_end, 'variant_path': l_0_variant_path})):
            yield event
    l_1_feature = missing
    yield '\n'
    yield str(context.call((undefined(name='namespace_end') if l_0_namespace_end is missing else l_0_namespace_end), (undefined(name='namespaces_as_array') if l_0_namespaces_as_array is missing else l_0_namespaces_as_array)))
    yield '\n\n#endif  // '
    yield str((undefined(name='header_guard') if l_0_header_guard is missing else l_0_header_guard))

blocks = {}
debug_info = '5=18&8=33&10=36&11=41&12=45&16=51&17=53&22=55&23=58&26=61&32=65&34=66&35=70&37=75&39=77'